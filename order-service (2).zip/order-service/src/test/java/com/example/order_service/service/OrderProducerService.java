package com.example.order_service.service;

//package com.example.orderservice.service;

import com.example.order_service.dto.OrderRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class OrderProducerService {

    private static final String TOPIC = "orders-topic";

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    public String sendOrder(OrderRequest order) {
        try {
            order.setOrderId(order.getOrderId());

            ObjectMapper mapper = new ObjectMapper();
            String json = mapper.writeValueAsString(order);

            kafkaTemplate.send(TOPIC, order.getOrderId(), json);

            return "Order sent successfully";

        } catch (Exception e) {
            return "Error sending order";
        }
    }
}