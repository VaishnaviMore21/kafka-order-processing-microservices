package com.example.order_service.controller;


import com.example.order_service.dto.OrderRequest;
import com.example.order_service.service.OrderProducerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderProducerService service;

    @PostMapping
    public String createOrder(@RequestBody OrderRequest order) {
        return service.sendOrder(order);
    }
}
