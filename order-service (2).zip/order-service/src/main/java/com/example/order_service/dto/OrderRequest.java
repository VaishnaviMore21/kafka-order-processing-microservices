//package com.example.order_service.dto;
//
//public class OrderRequest {
//}
package com.example.order_service.dto;

import lombok.Data;

@Data
public class OrderRequest {

    private String orderId;
    private String productName;
    private double price;
}